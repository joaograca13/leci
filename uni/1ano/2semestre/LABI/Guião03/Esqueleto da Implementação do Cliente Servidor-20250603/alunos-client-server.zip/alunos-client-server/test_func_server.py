import pytest
from subprocess import Popen
from subprocess import PIPE

def test_lack_args():
	proc = Popen("python3 server.py", stdout=PIPE, shell=True)
	#...

def test_wrong_args():
	proc = Popen("python3 server.py -1000", stdout=PIPE, shell=True)
	#...

	proc = Popen("python3 server.py aveiro", stdout=PIPE, shell=True)
	#...

	
