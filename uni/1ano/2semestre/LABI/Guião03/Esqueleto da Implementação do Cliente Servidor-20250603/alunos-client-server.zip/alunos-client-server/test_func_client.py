import pytest
from subprocess import Popen
from subprocess import PIPE

def test_lack_args():
	proc = Popen("python3 client.py manel", stdout=PIPE, shell=True)
	#...

def test_excess_args():
	proc = Popen("python3 client.py manel 1000 127.0.0.1 hostname", stdout=PIPE, shell=True)
	#...

def test_wrong_args():
	proc = Popen("python3 client.py manel -1000", stdout=PIPE, shell=True)
	#...
	
	proc = Popen("python3 client.py manel xpto", stdout=PIPE, shell=True)
	#...
