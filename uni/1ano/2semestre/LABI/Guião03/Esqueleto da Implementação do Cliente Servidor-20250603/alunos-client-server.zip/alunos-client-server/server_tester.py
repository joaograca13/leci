#!/usr/bin/python3

import sys
import socket
import select
import json
import base64
import csv

import random
from common_comm import send_dict, recv_dict, sendrecv_dict

from Cryptodome.Cipher import AES
from Cryptodome.Hash import SHA256

# Dicionário com a informação relativa aos clientes
users = {
			"anton": { "socket": '<socket raddr=("127.0.0.1", 46192)>', "cipher": None, "numbers": [] },
			"jonas": { "socket": '<socket raddr=("127.0.0.1", 46194)>', "cipher": None, "numbers": [] },
			"manel": { "socket": '<socket raddr=("127.0.0.1", 46196)>', "cipher": b")6\x0c\xba\xf8\x14\xa7iU\xac\x8a~\xe0H~0", "numbers": [66, 77, 88, 55], "min": 55, "max": 88 },
			"maria": { "socket": '<socket raddr=("127.0.0.1", 46198)>', "cipher": None, "numbers": [-100, 100] }
		}


# Função para procurar o client_id a partir do seu socket no dicionário de clientes - devolve None se não encontrar
def find_client_id (client_sock):
	return None

# Função para encriptar valores a enviar em formato json com codificação base64
def encrypt_intvalue (client_id, data):
	return data

# Função para desencriptar valores recebidos em formato json com codificação base64
def decrypt_intvalue (client_id, data):
	return data

# Incomming message structure:
# { op = "START", client_id, [cipher] }
# { op = "QUIT" }
# { op = "NUMBER", number }
# { op = "STOP" }
#
# Outcomming message structure:
# { op = "START", status }
# { op = "QUIT" , status }
# { op = "NUMBER", status }
# { op = "STOP", status, min, max }


#
# Suporte de descodificação da operação pretendida pelo cliente
#
def new_msg (client_sock):
	request = recv_dict (client_sock)
	print( "Command: %s" % (str(request)) )

	op = request["op"]
	if op == "START":   # Add a client to the game
		response = new_client (client_sock, request)
	elif op == "QUIT": # 
		response = quit_client (client_sock)
	elif op == "NUMBER": # 
		response = number_client (client_sock, request)
	elif op == "STOP": # 
		response = stop_client (client_sock, request)
	else:
		response = { "op": op, "status" : False, "error": "Operação inexistente" }

	print (response)
	send_dict (client_sock, response )

#
# Suporte da criação de um novo cliente - operação START
#
def new_client (client_sock, request):
	return None

#
# Suporte da eliminação de um cliente
#
def clean_client (client_sock):
	return None

#
# Suporte do pedido de desistência de um cliente - operação QUIT
#
def quit_client (client_sock):
	return None

#
# Suporte da criação de um ficheiro csv com o respectivo cabeçalho
#
def create_file ():
	with open("result.csv", "w", newline="") as csvfile:
		columns = ["client_id", "number_of_numbers", "min", "max"]

		fw = csv.DictWriter (csvfile, delimiter=",", fieldnames=columns)
		fw.writeheader()

#
# Suporte da actualização de um ficheiro csv com a informação do cliente e resultado
#
def update_file (client_id, size, minimal, maximal):
	return None

#
# Suporte do processamento do número de um cliente - operação NUMBER
#
def number_client (client_sock, request):
	return None

#
# Suporte do pedido de terminação de um cliente - operação STOP
#
def stop_client (client_sock, request):
	return None
