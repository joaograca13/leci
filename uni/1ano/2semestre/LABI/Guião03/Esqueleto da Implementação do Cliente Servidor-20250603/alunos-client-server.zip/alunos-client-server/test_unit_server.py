import pytest
from server_tester import *

def test_find_client_id ():
	# cliente 1
	assert find_client_id ('<socket raddr=("127.0.0.1", 46192)>') == "anton"
	# cliente 2
	assert find_client_id ('<socket raddr=("127.0.0.1", 46194)>') == "jonas"
	# cliente 3
	assert find_client_id ('<socket raddr=("127.0.0.1", 46196)>') == "manel"
	# client inexistente
	assert find_client_id ('<socket raddr=("127.0.0.1", 46190)>') == None

def test_new_client ():
	# cliente existente "anton" - erro de cliente existente
	#...
	
	# cliente novo "carlos" com '<socket raddr=("127.0.0.1", 46200)>' - aceita cliente
	#...

	# cliente existente - não aceita outra vez o cliente carlos" e dá erro de cliente existente
	#...
	
def test_clean_client ():
	# client inexistente - não elimina o cliente
	response = stop_client ('<socket raddr=("127.0.0.1", 46190)>', request)
	#...

	# cliente existente - elimina o cliente
	#...

def test_quit_client ():
	# cliente inexistente - erro de cliente inexistente
	response = stop_client ('<socket raddr=("127.0.0.1", 46190)>', request)
	#...

	# cliente novo "carlos" com '<socket raddr=("127.0.0.1", 46200)>' - aceita cliente sair
	#...

def test_number_client ():
	# cliente inexistente - erro de cliente inexistente
	response = stop_client ('<socket raddr=("127.0.0.1", 46190)>', request)
	#...

	# cliente existente "anton" com '<socket raddr=("127.0.0.1", 46192)>' - executa o number e aceita os números 25, 5, 45, 99
	# inserir sucessivamente os números indicados
	#...

	# cliente existente "manel" que já fez STOP e tem mínimo e máximo calculados - erro Cliente inativo
	#...

def test_stop_client ():
	request = { "op": "STOP"}
	# cliente inexistente - erro de cliente inexistente
	response = stop_client ('<socket raddr=("127.0.0.1", 46190)>', request)
	#...
	
	# cliente existente "jonas" sem números - erro Dados insuficientes 
	#...

	# cliente existente "maria" com números e sem shasum - stop com resultado nínimo = -100 e máximo = 100
	#...

	# cliente existente "anton" com os números [25, 5, 45, 99] mas com shasum errada - erro Sintese inconsistente
	request = { "op": "STOP", "shasum": "tgIJCOlnZbba5K5jLvRVEyYbhjsOf+ddDDJnJf4*=/&%" }
	#...

	# cliente existente "anton" e com shasum correta - stop com resultado nínimo = 5 e máximo = 99
	request = { "op": "STOP", "shasum": "tgIJCOlnZbba5K5jLvRVEyYbhjsOf+ddDDJnJf4Gfik=" }
	#...
